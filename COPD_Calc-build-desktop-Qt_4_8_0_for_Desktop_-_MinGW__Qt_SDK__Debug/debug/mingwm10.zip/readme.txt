This file was downloaded from: http://www.dll-files.com

We also have a software available that can solve the problem with your dll file for you. It's called "DLL-files Fixer" and you can get it from http://www.dll-files.com/fixer

Installation instructions:

1. Open the zip-file you downloaded from DLL-files.com.

2. Extract the .dll-file to a location on your computer. We recommend you to unzip the file to the directory of the program that is requesting the file. If that doesn't work, you will have to extract the file to your system directory.  
By default, this is C:\Windows\System (Windows 95/98/Me), C:\WINNT\System32 (Windows NT/2000), or C:\Windows\System32 (Windows XP, Vista, 7).
Make sure overwrite any existing files (but make a backup copy of the original file).  

3. Reboot your computer.

4. If the problem still occurs, try the following:

	1. Press Start and select Run.
	2. Type CMD and press Enter (or if you use Windows ME, type COMMAND).
	3. Type regsvr32 "filename".dll and press Enter.

If you have any other problems, see our HELP-section at www.dll-files.com